Arch Linux configuration files for programs and BSPWM

Requirements to run full setup with applets...
+  dzen2 - for the clickable applets
+  conky - for the top bar
+  mpd - for the music applet
+  mpc - for the music applet
+  gmrun - to run programs
+  docky - dock launcher at the bottom
+  vnstat - for network applet statistics
+  xdotool - to get current mouse position
+  tint2 - to get windowlist on statusbar

For making things look nice, i use
+  hsetroot - to set wallpaper
+  compton - to set shadows / transparency of windows

CURRENT:
![Alt text](https://raw.github.com/windelicato/dotfiles/master/screenshot.png "SCREENSHOT")
