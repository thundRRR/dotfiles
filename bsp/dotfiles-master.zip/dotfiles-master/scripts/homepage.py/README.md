homepage.py
===========

![Screenshot](http://ompldr.org/vZWY5NQ "screenshot")

**Requirements:**
- Python
- [HTML Tidy](http://tidy.sourceforge.net/)
